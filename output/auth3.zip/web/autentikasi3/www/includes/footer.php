    <footer class="footer">
        <div class="footer-container">
            <p>&copy; 2024 SecureVault. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
