        <footer class="footer">
            <p>&copy; <?php echo date('Y'); ?> FileVault Inc. All rights reserved.</p>
            <div class="footer-links">
                <a href="#privacy">Privacy Policy</a>
                <a href="#terms">Terms of Service</a>
                <a href="#support">Support</a>
            </div>
        </footer>
    </div>
</body>
</html>
